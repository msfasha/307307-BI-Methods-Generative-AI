import streamlit as st

# Headers and text
st.title("Content Display Demo")
st.header("This is a header")
st.subheader("This is a subheader")
st.text("This is plain text")
st.write("Write can handle almost anything!")

# Markdown support
st.markdown("### You can use **markdown** too!")

# Code display
st.code("""
def hello():
    print("Hello, Streamlit!")
""", language="python")

# LaTeX for mathematical formulas
st.latex(r"\sum_{i=1}^{n} x_i^2")
