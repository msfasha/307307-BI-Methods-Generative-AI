import streamlit as st
import pandas as pd
import numpy as np

st.title("Data Display Examples")

# Create a simple dataframe
data = {
    'Name': ['Alice', 'Bob', 'Charlie', 'Diana'],
    'Age': [25, 30, 35, 28],
    'City': ['New York', 'Paris', 'London', 'Tokyo']
}
df = pd.DataFrame(data)

# Display as a static table
st.subheader("Static Table")
st.table(df)

# Display as an interactive dataframe
st.subheader("Interactive Dataframe")
st.dataframe(df)

# You can also highlight specific values
st.subheader("Styled Dataframe")
st.dataframe(df.style.highlight_max(axis=0))

# Display metrics
st.subheader("Metrics")
col1, col2, col3 = st.columns(3)
col1.metric("Temperature", "70 °F", "1.2 °F")
col2.metric("Wind", "9 mph", "-8%")
col3.metric("Humidity", "86%", "4%")
