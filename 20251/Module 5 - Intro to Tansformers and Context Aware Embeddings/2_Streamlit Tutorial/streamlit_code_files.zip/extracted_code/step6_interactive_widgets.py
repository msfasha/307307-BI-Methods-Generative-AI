import streamlit as st

st.title("Interactive Widgets Demo")

# Text input
name = st.text_input("Enter your name:", "")
if name:
    st.write(f"Hello, {name}!")

# Number input
age = st.number_input("Enter your age:", min_value=0, max_value=120, value=25)
st.write(f"You are {age} years old")

# Slider
temperature = st.slider("Select temperature:", -10, 40, 20)
st.write(f"Current temperature: {temperature}°C")

# Select box
city = st.selectbox(
    "Choose your city:",
    ["New York", "London", "Paris", "Tokyo"]
)
st.write(f"You selected: {city}")

# Multi-select
hobbies = st.multiselect(
    "What are your hobbies?",
    ["Reading", "Sports", "Music", "Cooking", "Travel"]
)
st.write(f"Your hobbies: {', '.join(hobbies)}")

# Checkbox
agree = st.checkbox("I agree to the terms and conditions")
if agree:
    st.success("Thank you for agreeing!")

# Radio buttons
genre = st.radio(
    "What's your favorite movie genre?",
    ["Comedy", "Drama", "Action", "Horror"]
)
st.write(f"You selected: {genre}")

# Button
if st.button("Click me!"):
    st.balloons()  # Fun animation!
    st.write("Button was clicked!")
