import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

st.title("💰 Compound Interest Calculator")

st.write("""
This app helps you calculate how your investment will grow over time 
with compound interest. Adjust the parameters using the controls below.
""")

# Create input widgets in the sidebar
st.sidebar.header("Investment Parameters")
initial_investment = st.sidebar.number_input(
    "Initial Investment ($)", 
    min_value=100, 
    max_value=1000000, 
    value=10000, 
    step=100
)

monthly_contribution = st.sidebar.number_input(
    "Monthly Contribution ($)", 
    min_value=0, 
    max_value=10000, 
    value=500, 
    step=50
)

annual_rate = st.sidebar.slider(
    "Annual Interest Rate (%)", 
    min_value=0.0, 
    max_value=20.0, 
    value=7.0, 
    step=0.1
)

years = st.sidebar.slider(
    "Investment Period (years)", 
    min_value=1, 
    max_value=40, 
    value=20
)

# Calculate compound interest
months = years * 12
monthly_rate = annual_rate / 100 / 12

# Build the investment growth array
balance = np.zeros(months + 1)
balance[0] = initial_investment

for month in range(1, months + 1):
    balance[month] = balance[month - 1] * (1 + monthly_rate) + monthly_contribution

# Calculate totals
total_invested = initial_investment + (monthly_contribution * months)
final_balance = balance[-1]
total_interest = final_balance - total_invested

# Display results
st.header("Results")

col1, col2, col3 = st.columns(3)
col1.metric("Total Invested", f"${total_invested:,.2f}")
col2.metric("Final Balance", f"${final_balance:,.2f}")
col3.metric("Total Interest Earned", f"${total_interest:,.2f}", 
            delta=f"{(total_interest/total_invested)*100:.1f}%")

# Create visualization
st.header("Investment Growth Over Time")

fig, ax = plt.subplots(figsize=(10, 6))
time_periods = np.arange(0, months + 1) / 12  # Convert to years

# Calculate principal (money invested)
principal = np.array([initial_investment + (monthly_contribution * month) 
                      for month in range(months + 1)])

ax.plot(time_periods, balance, label='Total Balance', linewidth=2, color='green')
ax.plot(time_periods, principal, label='Principal (Invested)', 
        linewidth=2, linestyle='--', color='blue')
ax.fill_between(time_periods, principal, balance, alpha=0.3, color='green', 
                label='Interest Earned')

ax.set_xlabel('Years')
ax.set_ylabel('Amount ($)')
ax.set_title('Investment Growth with Compound Interest')
ax.legend()
ax.grid(True, alpha=0.3)
ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda x, p: f'${x:,.0f}'))

st.pyplot(fig)

# Show year-by-year breakdown
if st.checkbox("Show detailed year-by-year breakdown"):
    st.subheader("Annual Breakdown")
    
    yearly_data = []
    for year in range(years + 1):
        month_index = year * 12
        yearly_data.append({
            'Year': year,
            'Balance': balance[month_index],
            'Total Invested': initial_investment + (monthly_contribution * month_index),
            'Interest Earned': balance[month_index] - (initial_investment + (monthly_contribution * month_index))
        })
    
    df = pd.DataFrame(yearly_data)
    df['Balance'] = df['Balance'].map('${:,.2f}'.format)
    df['Total Invested'] = df['Total Invested'].map('${:,.2f}'.format)
    df['Interest Earned'] = df['Interest Earned'].map('${:,.2f}'.format)
    
    st.dataframe(df, use_container_width=True)
