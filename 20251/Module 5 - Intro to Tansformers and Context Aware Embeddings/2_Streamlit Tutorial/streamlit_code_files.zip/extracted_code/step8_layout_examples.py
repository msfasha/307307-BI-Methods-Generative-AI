import streamlit as st

st.title("Layout Examples")

# Create two columns
col1, col2 = st.columns(2)

with col1:
    st.header("Column 1")
    st.write("This content is in the first column")
    st.button("Button 1")

with col2:
    st.header("Column 2")
    st.write("This content is in the second column")
    st.button("Button 2")

# Create three columns with different widths
st.subheader("Columns with Different Widths")
col1, col2, col3 = st.columns([3, 1, 1])

col1.write("This column is 3x wider")
col2.write("Narrow")
col3.write("Narrow")

# Expandable sections
with st.expander("Click to expand"):
    st.write("Hidden content that appears when expanded")
    st.image("https://via.placeholder.com/300")

# Containers
container = st.container()
container.write("This is inside a container")

# Sidebar
st.sidebar.title("Sidebar")
st.sidebar.write("You can put widgets here")
sidebar_value = st.sidebar.slider("Sidebar slider", 0, 100, 50)
