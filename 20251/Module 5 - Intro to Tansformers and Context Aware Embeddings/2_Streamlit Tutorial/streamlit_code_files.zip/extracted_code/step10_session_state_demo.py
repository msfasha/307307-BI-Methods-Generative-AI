import streamlit as st

st.title("Session State Demo")

# Initialize session state variables
if 'count' not in st.session_state:
    st.session_state.count = 0

if 'name' not in st.session_state:
    st.session_state.name = ''

# Button to increment counter
if st.button('Increment Counter'):
    st.session_state.count += 1

st.write(f'Counter value: {st.session_state.count}')

# Text input that persists
st.session_state.name = st.text_input('Enter your name:', st.session_state.name)
if st.session_state.name:
    st.write(f'Hello, {st.session_state.name}! Your input will persist.')

# Reset button
if st.button('Reset Everything'):
    st.session_state.count = 0
    st.session_state.name = ''
    st.rerun()
