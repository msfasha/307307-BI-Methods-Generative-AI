import streamlit as st
import pandas as pd

st.title("File Upload Demo")

st.write("Upload a CSV file to see its contents")

uploaded_file = st.file_uploader("Choose a CSV file", type="csv")

if uploaded_file is not None:
    # Read the file
    df = pd.read_csv(uploaded_file)
    
    st.success("File uploaded successfully!")
    
    # Show basic information
    st.subheader("Dataset Information")
    st.write(f"Number of rows: {len(df)}")
    st.write(f"Number of columns: {len(df.columns)}")
    
    # Display the dataframe
    st.subheader("Data Preview")
    st.dataframe(df)
    
    # Show basic statistics
    if st.checkbox("Show statistical summary"):
        st.subheader("Statistical Summary")
        st.write(df.describe())
    
    # Let user select columns to visualize
    if len(df.columns) > 0:
        st.subheader("Visualize Data")
        column = st.selectbox("Select a column to visualize:", df.columns)
        
        if df[column].dtype in ['int64', 'float64']:
            st.line_chart(df[column])
        else:
            st.write("Selected column is not numeric")
