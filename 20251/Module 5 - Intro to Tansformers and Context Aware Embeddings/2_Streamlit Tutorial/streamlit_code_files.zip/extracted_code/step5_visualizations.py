import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

st.title("Data Visualization Examples")

# Generate sample data
chart_data = pd.DataFrame(
    np.random.randn(20, 3),
    columns=['A', 'B', 'C']
)

# Native Streamlit charts (simple and fast)
st.subheader("Line Chart")
st.line_chart(chart_data)

st.subheader("Area Chart")
st.area_chart(chart_data)

st.subheader("Bar Chart")
st.bar_chart(chart_data)

# Matplotlib integration
st.subheader("Matplotlib Figure")
fig, ax = plt.subplots()
ax.plot(chart_data['A'], label='Series A')
ax.plot(chart_data['B'], label='Series B')
ax.legend()
st.pyplot(fig)

# Map data (requires latitude and longitude)
st.subheader("Map Visualization")
map_data = pd.DataFrame(
    np.random.randn(100, 2) / [50, 50] + [37.76, -122.4],
    columns=['lat', 'lon']
)
st.map(map_data)
