import streamlit as st

# This is the simplest Streamlit app possible
st.title("My First Streamlit App")
st.write("Hello, World!")
