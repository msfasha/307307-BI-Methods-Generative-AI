import streamlit as st
import pandas as pd
import time

st.title("Caching Demo")

# Without caching - this will run every time the app reruns
def load_data_slow():
    time.sleep(3)  # Simulate slow loading
    return pd.DataFrame({
        'A': range(100),
        'B': range(100, 200)
    })

# With caching - this only runs once
@st.cache_data
def load_data_fast():
    time.sleep(3)  # Simulate slow loading
    return pd.DataFrame({
        'A': range(100),
        'B': range(100, 200)
    })

st.write("Click the button below and notice how the cached version is instant on subsequent clicks!")

if st.button('Load Data (Cached)'):
    with st.spinner('Loading data...'):
        df = load_data_fast()
    st.success('Done!')
    st.dataframe(df.head())
