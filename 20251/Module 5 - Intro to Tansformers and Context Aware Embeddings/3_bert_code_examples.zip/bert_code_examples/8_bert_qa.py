import streamlit as st
from transformers import pipeline

st.title("Example 8 — BERT-Large SQuAD QA")

qa = pipeline(
    "question-answering",
    model="bert-large-uncased-whole-word-masking-finetuned-squad",
    tokenizer="bert-large-uncased-whole-word-masking-finetuned-squad"
)

context = st.text_area("Context:",
    "BERT is a general-purpose language model...")

question = st.text_input("Question:", "What is BERT?")

if st.button("Answer"):
    result = qa(question=question, context=context)
    st.write("Answer:", result["answer"])
    st.write("Confidence:", result["score"])
